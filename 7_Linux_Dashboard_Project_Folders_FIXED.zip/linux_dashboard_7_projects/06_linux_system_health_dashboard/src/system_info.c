#include <stdio.h>
#include <sys/sysinfo.h>
int main(void){struct sysinfo s;if(sysinfo(&s)!=0){perror("sysinfo");return 1;}printf("Uptime: %ld seconds\\n",s.uptime);printf("Total RAM: %lu MB\\n",(unsigned long)(s.totalram*s.mem_unit/1024/1024));printf("Free RAM: %lu MB\\n",(unsigned long)(s.freeram*s.mem_unit/1024/1024));return 0;}
