# Seven Linux Dashboard Projects

1. Student Attendance Monitoring Dashboard
2. Student Academic Performance and Results Dashboard
3. Library Book and Circulation Management Dashboard
4. Inventory and Supply Chain Monitoring Dashboard
5. Employee Payroll and Salary Analytics Dashboard
6. Linux System Health and Process Monitoring Dashboard
7. Linux Log Analysis and Security Monitoring Dashboard

Each folder is a separate starter project. Open its README.md for GitHub Codespaces instructions. All included sample data is fictional.
